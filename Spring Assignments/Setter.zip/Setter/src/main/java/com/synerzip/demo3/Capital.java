package com.synerzip.demo3;

public class Capital {
	private String capitalName;

	public String getCapitalName() {
		return capitalName;
	}

	public void setCapitalName(String capitalName) {
		this.capitalName = capitalName;
	}
	

}