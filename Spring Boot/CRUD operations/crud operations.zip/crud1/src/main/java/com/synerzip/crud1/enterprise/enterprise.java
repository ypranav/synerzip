package com.synerzip.crud1.enterprise;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class enterprise {
    
	
	@Id
	private Long UserID;
	private String Username;
	private int age;
	
	@Override
	public String toString() {
		return "enterprise [UserID=" + UserID + ", Username=" + Username + ", age=" + age + "]";
	}

	public Long getUserID() {
		return UserID;
	}

	public void setUserID(Long userID) {
		UserID = userID;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
	
	
	
	
}